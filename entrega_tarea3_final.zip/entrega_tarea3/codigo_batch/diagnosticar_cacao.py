from pyspark.sql import SparkSession
from pyspark.sql.functions import col, trim

spark = (
    SparkSession.builder
    .appName("Diagnostico_CSV_Cacao")
    .getOrCreate()
)

ruta = "/home/vboxuser/bigdata/datos/cacao_20261027.csv"

df = (
    spark.read
    .option("header", "true")
    .option("inferSchema", "false")
    .option("multiLine", "true")
    .option("encoding", "UTF-8")
    .option("quote", '"')
    .option("escape", '"')
    .option("mode", "PERMISSIVE")
    .csv(ruta)
)

print("\n=== DIAGNOSTICO DEL ARCHIVO ===")
print("Version de Spark:", spark.version)
print("Columnas detectadas:", len(df.columns))
print("Filas detectadas:", df.count())

print("\n=== ENCABEZADOS ORIGINALES ===")
for i, nombre in enumerate(df.columns, start=1):
    print(f"{i}. {nombre!r}")

print("\n=== PRIMERAS 3 FILAS ===")
df.show(3, truncate=False)

spark.stop()
