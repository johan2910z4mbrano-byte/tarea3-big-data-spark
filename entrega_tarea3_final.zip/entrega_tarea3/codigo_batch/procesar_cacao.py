from pyspark.sql import SparkSession
from pyspark.sql.functions import col, trim

spark = (
    SparkSession.builder
    .appName("Tarea3_Procesamiento_Batch_Cacao")
    .getOrCreate()
)

ruta = "/home/vboxuser/bigdata/datos/cacao_20261027.csv"
salida = "/home/vboxuser/bigdata/resultados/cacao_limpio"

df = (
    spark.read
    .option("header", "true")
    .option("multiLine", "true")
    .option("encoding", "UTF-8")
    .option("quote", '"')
    .option("escape", '"')
    .csv(ruta)
)

nombres = [
    "codigo_departamento",
    "departamento",
    "codigo_municipio",
    "municipio",
    "grupo_cultivo",
    "subgrupo_cultivo",
    "cultivo",
    "sistema_productivo",
    "anio",
    "periodo",
    "area_sembrada_ha",
    "area_cosechada_ha",
    "produccion_t",
    "rendimiento_t_ha",
    "estado_fisico_produccion",
    "nombre_cientifico",
    "ciclo_cultivo"
]

if len(df.columns) != len(nombres):
    raise ValueError(
        f"Se esperaban 17 columnas, pero Spark detectó {len(df.columns)}."
    )

# Asignar nombres seguros, sin caracteres especiales
df = df.toDF(*nombres)

# Eliminar espacios sobrantes de las columnas de texto
for nombre, tipo in df.dtypes:
    if tipo == "string":
        df = df.withColumn(nombre, trim(col(nombre)))

print("=== PROCESAMIENTO BATCH ===")
print("Versión de Spark:", spark.version)
print("Filas leídas:", df.count())
print("Columnas:", len(df.columns))

print("=== ESQUEMA ===")
df.printSchema()

print("=== PRIMERAS 5 FILAS ===")
df.show(5, truncate=False)

# Guardar en una carpeta nueva de resultados
df.write.mode("overwrite").option("header", "true").option("encoding", "UTF-8").csv(salida)

print("ARCHIVO PROCESADO GUARDADO EN:", salida)

spark.stop()
