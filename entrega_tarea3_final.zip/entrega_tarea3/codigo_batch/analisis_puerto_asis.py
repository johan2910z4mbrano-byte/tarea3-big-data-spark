from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, trim, upper, regexp_replace,
    sum as spark_sum, avg, max as spark_max
)

spark = (
    SparkSession.builder
    .appName("Analisis_Cacao_Puerto_Asis")
    .getOrCreate()
)

ruta = "/home/vboxuser/bigdata/resultados/cacao_limpio"

df = (
    spark.read
    .option("header", "true")
    .option("encoding", "UTF-8")
    .csv(ruta)
)

# Filtrar Puerto Asís
df = df.filter(
    upper(trim(col("municipio"))).contains("PUERTO ASIS")
)

# Convertir el año y las variables agrícolas
df = df.withColumn(
    "anio_analisis",
    col("periodo").cast("int")
)

variables = [
    "area_sembrada_ha",
    "area_cosechada_ha",
    "produccion_t",
    "rendimiento_t_ha"
]

for nombre in variables:
    df = df.withColumn(
        nombre,
        regexp_replace(trim(col(nombre)), ",", ".").cast("double")
    )

print("=== RESUMEN ANUAL DE PUERTO ASIS ===")

resumen = (
    df.groupBy("anio_analisis")
    .agg(
        spark_sum("area_sembrada_ha").alias("area_sembrada_ha"),
        spark_sum("area_cosechada_ha").alias("area_cosechada_ha"),
        spark_sum("produccion_t").alias("produccion_t"),
        avg("rendimiento_t_ha").alias("rendimiento_promedio_t_ha")
    )
    .orderBy("anio_analisis")
)

resumen.show(20, truncate=False)

salida = "/home/vboxuser/bigdata/resultados/resumen_puerto_asis"
resumen.coalesce(1).write.mode("overwrite").option("header", "true").csv(salida)

print("Resumen guardado en:", salida)

spark.stop()
