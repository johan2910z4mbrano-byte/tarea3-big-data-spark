from pyspark.sql import SparkSession

spark = (
    SparkSession.builder
    .appName("Tarea3_Cacao_Verificacion")
    .getOrCreate()
)

ruta = "/home/vboxuser/bigdata/datos/cacao_20261027.csv"

df = (
    spark.read
    .option("header", "true")
    .option("inferSchema", "true")
    .option("multiLine", "true")
    .option("encoding", "UTF-8")
    .option("quote", '"')
    .option("escape", '"')
    .csv(ruta)
)

print("VERSION DE SPARK:", spark.version)
print("COLUMNAS DETECTADAS:", len(df.columns))
print("NOMBRES DE COLUMNAS:")
for columna in df.columns:
    print(repr(columna))

print("ESQUEMA:")
df.printSchema()

print("TOTAL DE FILAS:", df.count())

print("PRIMERAS 5 FILAS:")
df.show(5, truncate=False)

spark.stop()
