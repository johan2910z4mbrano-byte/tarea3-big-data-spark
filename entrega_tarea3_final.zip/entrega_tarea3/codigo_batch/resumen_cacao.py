from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, trim, upper, regexp_replace,
    count, sum as spark_sum, avg, max as spark_max
)

spark = (
    SparkSession.builder
    .appName("Tarea3_Resumen_Cacao")
    .getOrCreate()
)

ruta = "/home/vboxuser/bigdata/resultados/cacao_limpio"

df = (
    spark.read
    .option("header", "true")
    .option("encoding", "UTF-8")
    .csv(ruta)
)

print("\n=== DIMENSIONES ===")
print("Filas:", df.count())
print("Columnas:", len(df.columns))

print("\n=== VALORES DISTINTOS DE ANIO Y PERIODO ===")
df.select("anio", "periodo").distinct().orderBy("anio").show(15, False)

print("\n=== NULOS POR COLUMNA ===")
for nombre in df.columns:
    nulos = df.filter(
        col(nombre).isNull() | (trim(col(nombre)) == "")
    ).count()
    print(f"{nombre}: {nulos}")

print("\n=== DUPLICADOS EXACTOS ===")
total = df.count()
unicos = df.dropDuplicates().count()
print("Filas duplicadas exactas:", total - unicos)

print("\n=== REGISTROS DE PUERTO ASIS ===")
puerto_asis = df.filter(
    upper(trim(col("municipio"))).contains("PUERTO ASIS")
)
print("Registros encontrados:", puerto_asis.count())
puerto_asis.select(
    "departamento", "municipio", "anio", "periodo",
    "area_sembrada_ha", "area_cosechada_ha",
    "produccion_t", "rendimiento_t_ha"
).show(30, False)

spark.stop()
