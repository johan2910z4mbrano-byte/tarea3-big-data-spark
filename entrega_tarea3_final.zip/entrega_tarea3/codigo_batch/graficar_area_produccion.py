import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import csv
import glob
import os

carpeta = "/home/vboxuser/bigdata/resultados/resumen_puerto_asis"
archivos = glob.glob(os.path.join(carpeta, "part-*.csv"))

if not archivos:
    raise FileNotFoundError("No se encontró el resumen anual de Spark.")

anios = []
areas = []
producciones = []

with open(archivos[0], "r", encoding="utf-8-sig", newline="") as archivo:
    for fila in csv.DictReader(archivo):
        anios.append(int(fila["anio_analisis"]))
        areas.append(float(fila["area_cosechada_ha"]))
        producciones.append(float(fila["produccion_t"]))

datos = sorted(zip(anios, areas, producciones))
anios, areas, producciones = map(list, zip(*datos))

fig, ax1 = plt.subplots(figsize=(10, 6))

ax1.plot(anios, producciones, marker="o", label="Producción (t)")
ax1.set_xlabel("Año")
ax1.set_ylabel("Producción (toneladas)")
ax1.set_xticks(anios)
ax1.tick_params(axis="x", rotation=45)

ax2 = ax1.twinx()
ax2.plot(anios, areas, marker="s", linestyle="--",
         label="Área cosechada (ha)")
ax2.set_ylabel("Área cosechada (hectáreas)")

fig.suptitle("Producción y área cosechada de cacao en Puerto Asís")
fig.tight_layout()

salida = "/home/vboxuser/bigdata/resultados/area_y_produccion_puerto_asis.png"
fig.savefig(salida, dpi=150)
plt.close(fig)

print("Gráfica guardada en:", salida)
print("Años representados:", len(anios))
