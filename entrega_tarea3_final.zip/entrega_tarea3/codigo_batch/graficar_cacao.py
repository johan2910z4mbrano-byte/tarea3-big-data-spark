import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import csv
import glob
import os

carpeta = "/home/vboxuser/bigdata/resultados/resumen_puerto_asis"
archivos = glob.glob(os.path.join(carpeta, "part-*.csv"))

if not archivos:
    raise FileNotFoundError("No se encontró el CSV del resumen anual.")

datos = []
with open(archivos[0], "r", encoding="utf-8-sig", newline="") as archivo:
    lector = csv.DictReader(archivo)
    for fila in lector:
        datos.append((
            int(fila["anio_analisis"]),
            float(fila["produccion_t"])
        ))

datos.sort(key=lambda x: x[0])
anios = [x[0] for x in datos]
produccion = [x[1] for x in datos]

plt.figure(figsize=(10, 6))
plt.plot(anios, produccion, marker="o")
plt.title("Producción anual de cacao en Puerto Asís (2007–2018)")
plt.xlabel("Año")
plt.ylabel("Producción (toneladas)")
plt.xticks(anios, rotation=45)
plt.grid(True, alpha=0.3)
plt.tight_layout()

salida = "/home/vboxuser/bigdata/resultados/produccion_puerto_asis.png"
plt.savefig(salida, dpi=150)
plt.close()

print("Gráfica guardada en:", salida)
print("Años representados:", len(anios))
