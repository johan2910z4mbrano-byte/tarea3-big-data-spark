from pyspark.sql import SparkSession
from pyspark.sql.functions import col, sum as spark_sum, count

spark = (
    SparkSession.builder
    .appName("Tarea3_Validacion_Cacao")
    .getOrCreate()
)

ruta = "/home/vboxuser/bigdata/resultados/cacao_limpio"

df = (
    spark.read
    .option("header", "true")
    .option("encoding", "UTF-8")
    .csv(ruta)
)

print("=== DIMENSIONES DEL DATASET ===")
print("Filas:", df.count())
print("Columnas:", len(df.columns))

print("=== VALORES NULOS POR COLUMNA ===")
df.select([
    spark_sum(
        col(c).isNull().cast("int")
    ).alias(c)
    for c in df.columns
]).show(truncate=False)

print("=== REGISTROS DUPLICADOS ===")
total = df.count()
unicos = df.dropDuplicates().count()
print("Filas totales:", total)
print("Filas duplicadas exactas:", total - unicos)

print("=== DEPARTAMENTOS REGISTRADOS ===")
df.select("departamento").distinct().orderBy("departamento").show(40, truncate=False)

print("=== REGISTROS DE PUTUMAYO ===")
df.filter(
    col("departamento").contains("PUTUMAYO")
).select(
    "departamento", "municipio", "anio",
    "produccion_t", "rendimiento_t_ha"
).show(30, truncate=False)

spark.stop()
