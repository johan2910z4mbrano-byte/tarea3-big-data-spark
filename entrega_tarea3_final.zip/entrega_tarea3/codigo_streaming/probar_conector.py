from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("PruebaConectorKafka") \
    .getOrCreate()

print("PRUEBA_SPARK_OK")
print("Version de Spark:", spark.version)

spark.stop()
