import json
import time
from datetime import datetime
from kafka import KafkaProducer

productor = KafkaProducer(
    bootstrap_servers=["localhost:9092"],
    value_serializer=lambda dato: json.dumps(dato).encode("utf-8")
)

eventos = [
    {"productor_id": "SIM001", "municipio": "Puerto Asis", "cantidad_kg": 25.5},
    {"productor_id": "SIM002", "municipio": "Puerto Asis", "cantidad_kg": 40.0},
    {"productor_id": "SIM003", "municipio": "Puerto Asis", "cantidad_kg": 32.0},
]

try:
    for evento in eventos:
        evento["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        productor.send("tarea3-eventos", evento).get(timeout=10)
        print("Evento enviado:", evento)
        time.sleep(3)
finally:
    productor.flush()
    productor.close()
