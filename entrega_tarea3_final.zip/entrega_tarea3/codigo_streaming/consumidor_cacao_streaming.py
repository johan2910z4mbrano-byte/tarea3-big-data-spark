from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json, to_timestamp
from pyspark.sql.types import (
    StructType, StructField, StringType, DoubleType
)

spark = (
    SparkSession.builder
    .appName("ConsumidorCacaoStreaming")
    .getOrCreate()
)

spark.sparkContext.setLogLevel("WARN")

esquema = StructType([
    StructField("productor_id", StringType(), True),
    StructField("municipio", StringType(), True),
    StructField("cantidad_kg", DoubleType(), True),
    StructField("timestamp", StringType(), True)
])

eventos = (
    spark.readStream
    .format("kafka")
    .option("kafka.bootstrap.servers", "localhost:9092")
    .option("subscribe", "tarea3-eventos")
    .option("startingOffsets", "latest")
    .load()
)

datos = (
    eventos
    .selectExpr("CAST(value AS STRING) AS mensaje")
    .select(from_json(col("mensaje"), esquema).alias("dato"))
    .select("dato.*")
    .withColumn("fecha_evento", to_timestamp(col("timestamp")))
)

consulta = (
    datos.writeStream
    .format("console")
    .outputMode("append")
    .option("truncate", "false")
    .option("checkpointLocation",
            "/home/vboxuser/bigdata/checkpoints/cacao_streaming_nuevo")
    .start()
)

print("Consumidor de cacao iniciado. Esperando eventos de Kafka...")
consulta.awaitTermination()
