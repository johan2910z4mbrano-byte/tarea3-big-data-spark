# Tarea 3 - Big Data con Apache Spark

## Descripción
Proyecto académico de procesamiento de datos de cacao mediante Apache Spark.
Incluye procesamiento por lotes y procesamiento de eventos en tiempo real con
Apache Kafka y Spark Structured Streaming.

Los eventos identificados como SIM son datos simulados para pruebas; no son
registros reales de productores.

## Estructura
- codigo_batch/: limpieza, validación, análisis y visualización de datos históricos.
- codigo_streaming/: consumidor Spark Streaming, generador de eventos y prueba del conector.
- evidencias/: capturas y resultados de ejecución.
- documentacion/: documentación del proyecto.

## Tecnologías
- Ubuntu
- Java
- Python
- Apache Spark 3.5.6
- Apache Kafka 3.9.1
- Conector Spark SQL Kafka 3.5.6

## Procesamiento por lotes
Los scripts de codigo_batch procesan el conjunto histórico de cacao, realizan
validaciones, generan resúmenes y producen visualizaciones. El conjunto de datos
histórico no representa eventos individuales en tiempo real.

Ejecutar los scripts desde el entorno donde están instalados Spark y PySpark,
verificando primero las rutas de entrada y salida configuradas en cada archivo.

## Procesamiento en tiempo real
1. Iniciar Kafka con la configuración KRaft:
   config/kraft/server.properties
2. Crear el tópico si no existe:
   kafka-topics.sh --create --topic tarea3-eventos --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1
3. Iniciar el consumidor:
   spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.6 codigo_streaming/consumidor_cacao_streaming.py
4. En otra terminal, generar eventos simulados:
   python3 codigo_streaming/generador_eventos_cacao.py

El consumidor muestra los eventos procesados en la consola. El checkpoint
utilizado es /home/vboxuser/bigdata/checkpoints/cacao_streaming_nuevo.

## Evidencia de funcionamiento
Durante la prueba se enviaron tres eventos simulados para Puerto Asís:
SIM001: 25.5 kg; SIM002: 40.0 kg; SIM003: 32.0 kg.
Spark mostró los registros en microbatches. El total de 97.5 kg corresponde
exclusivamente a estos eventos de prueba.

## Consideraciones
- Los archivos originales se conservaron en ~/bigdata.
- Los resultados de procesamiento por lotes se encuentran en ~/bigdata/resultados.
- Antes de ejecutar los scripts en otro equipo, revisar rutas, versiones y dependencias.
- Añadir las referencias y los datos completos de la fuente del conjunto de datos
  en el informe académico.
